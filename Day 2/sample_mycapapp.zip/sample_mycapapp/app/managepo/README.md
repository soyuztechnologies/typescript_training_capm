## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Tue Feb 17 2026 18:06:09 GMT+0530 (India Standard Time)|
|**App Generator**<br>@sap/generator-fiori-elements|
|**App Generator Version**<br>1.13.6|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>List Report Page V4|
|**Service Type**<br>Local Cap|
|**Service URL**<br>http://localhost:4004/odata/v4/CatalogService/
|**Module Name**<br>managepo|
|**Application Title**<br>manage po|
|**Namespace**<br>anubhav.ui|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.144.1|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|
|**Main Entity**<br>PurchaseOrderSet|
|**Navigation Entity**<br>Items|

## managepo

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply start your CAP project and navigate to the following location in your browser:

http://localhost:4004/managepo/webapp/index.html

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


